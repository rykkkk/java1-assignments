/**
 * Krista Ryk
 * 991406369
 * Assignment 4
 * 11/28/2020
 */
package paytime;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int numWorkers = 1;
        boolean tryAgain = false;
        System.out.println("Weekly Pay calculator");
        System.out.println("^^^^^^^^^^^^^^^^^^^^^");

        do {
            Scanner k = new Scanner(System.in);
            System.out.print("Enter Worker number: ");
            int empNum = k.nextInt();

            //worker object will be named one.
            Worker one = new Worker();

            /*calling bool function to check if worker is valid employee*/
            while (one.isEmployee(empNum) == false) {
                System.out.print("Invalid, enter proper Worker number: ");
                empNum = k.nextInt();
                one.isEmployee(empNum);
            }

            System.out.print("Enter first name: ");
            String first = k.next();
            System.out.print("Enter last name: ");
            String last = k.next();

            System.out.print("Enter hours worked (h): ");
            double hours = k.nextDouble();
            while (hours < 0 || hours > 168) {
                /*maximum hours worked in a week = 24x7, min = 0*/
                System.out.print("Invalid, enter hours worked in 1 week: ");
                hours = k.nextDouble();
            }

            System.out.print("Enter hourly wage ($/h): ");
            double wage = k.nextDouble();
            while (wage < 0) {
                /*wage must be over $0/h*/
                System.out.print("Invalid, enter a non-negative rate: ");
                wage = k.nextDouble();
            }

            //System.out.println("");
            /*output as %s bc they have been turned into strings 
        just to change their deci pts 2*/
            System.out.printf("\nFor worker number #%d, "
                    + "%s:\n"
                    + "Weekly pay is $%s, \n"
                    + "Taxes paid is $%s, \n"
                    + "Net pay is $%s\n", empNum, one.chngName(first, last),
                    one.getWeek(hours, wage), one.getTax(hours, wage),
                    one.getNetPay(hours, wage));

            /*--------------------------------------------------------------------*/
            System.out.print("\nWould you like to calculate pay for "
                    + "another worker? (y/n): ");
            Scanner ask = new Scanner(System.in);
            String ans = ask.next();
            if (ans.contains("y")) {//if user types anything with a 'y'>try again
                tryAgain = true;
                numWorkers++;
            } else {//if user types anything with no 'n' >> program will end
                tryAgain = false;
            }
        } while (tryAgain == true);

        System.out.printf("\nNumber of workers processed: %d", numWorkers);
        System.out.println("\n\nCreated by Krista Ryk, #991406369. Nov 28 2020");
    }

}
