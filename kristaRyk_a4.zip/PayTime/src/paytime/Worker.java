/**
 * Krista Ryk
 * 991406369
 * Assignment 4
 * 11/28/2020
 */
package paytime;

import java.util.Arrays;
import java.text.DecimalFormat;

public class Worker {

    private final int[] empNumbers = {101, 103, 106, 109, 110, 113, 116, 118, 120};

    public boolean isEmployee(int empNum) {
        //do not need to sort bc array is already sorted
        boolean worksHere = true;
        if (Arrays.binarySearch(empNumbers, empNum) <= -1) {
            worksHere = false;
        }
        return worksHere;
    }

    public String chngName(String first, String last) {

        first = first.substring(0, 1).toUpperCase() + first.substring(1);
        last = last.substring(0, 1).toUpperCase() + last.substring(1);
        String fullname = first + " " + last;
        return fullname;
    }

    private double setWeekPay(double hours, double wage) {
        //calculate pay regular pay = hoursWorked * hourlyRate
        double weekPay = hours * wage;
        return weekPay;
    }
    DecimalFormat deci = new DecimalFormat(".##");

    public String getWeek(double hours, double wage) {
        return deci.format(setWeekPay(hours, wage));
    }

    private double setTax(double hours, double wage) {
        double weekPay = setWeekPay(hours, wage);
        double taxedPay = 0;
        if (weekPay < 300.01) {
            taxedPay = 0.10 * weekPay;
        } else if (weekPay < 400.01) {
            taxedPay = 0.12 * weekPay;
        } else if (weekPay < 500.01) {
            taxedPay = 0.15 * weekPay;
        } else if (weekPay >= 500.01) {
            taxedPay = 0.20 * weekPay;
        }
        return taxedPay;
    }

    public String getTax(double hours, double wage) {
        return deci.format(setTax(hours, wage));
    }

    private double setNetPay(double hours, double wage) {

        double netPay = setWeekPay(hours, wage) - setTax(hours, wage);

        return netPay;
    }
    
    public String getNetPay(double hours, double wage) {
        return deci.format(setNetPay(hours, wage));
    }
     /*   
       I am turning the calculated values into strings ONLY to display them 
        with two decimal places. I dont believe we learned how to do it without 
        changing them to strings, this is just the only way i know how to
     */
}
