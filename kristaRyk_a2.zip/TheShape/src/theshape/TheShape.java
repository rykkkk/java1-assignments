/**
 * Krista Ryk
 * 991406369 Assignment 2
 * October 6 2020
 */
package theshape;

import java.util.Scanner;

public class TheShape {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);//scanner for shape num

        Scanner u = new Scanner(System.in);
        /*new scanner u for user input of possible double values of shape 
        descriptors like height, base, radius etc
        I am defining it outside of the main method to avoid creating new 
        scanners for each shape's new variable */

        System.out.println("^^^^^^^^^^^^^^^^\n"
                + "SHAPE CALCULATOR\n"
                + "^^^^^^^^^^^^^^^^\n"
                + "Enter 1 for TRIANGLE\n"
                + "Enter 2 for RECTANGLE\n"
                + "Enter 3 for CIRCLE\n"
                + "^^^^^^^^^^^^^^^^");
        System.out.print("Enter shape number: ");
        int shapeNum = s.nextInt();
        /* shape number can only be accepted as an integer*/
        
        
        /* 
        if shape number entered is 1 or 2 or 3 THEN
        proceed as shapeNum variable
        IF NOT 1 or 2 or 3 : I will set it to 4, which is invalid and will 
        take us to the default case output and no calculations will be done 
        */
        shapeNum = (shapeNum == 1 || shapeNum == 2 || shapeNum == 3 ) 
                ? shapeNum   : 4;


        switch (shapeNum) {
            case 1://triangle
                System.out.println("\nYou have selected: TRIANGLE\n");
                System.out.print("Enter height: ");

                double triHeight = u.nextDouble();

                //check if values are > 0
                if (triHeight < 1) {
                    System.out.print("\nERROR: Not a valid entry. ");
                    System.out.print("Enter only values higher than 0\n");
                } else {//will only work with positive height values 

                    System.out.print("Enter base: ");

                    double triBase = u.nextDouble();

                    if (triBase < 1) {
                        System.out.print("\nERROR: Not a valid entry. ");
                        System.out.print("Enter only values higher than 0\n");
                    } else {
                        /*only after base and height are verified as positive 
                          then we can do the area calculations*/

                        double triArea = (0.5) * triBase * triHeight;
                        System.out.print("\nThe area of this triangle is: ");
                        System.out.print(triArea + "\n");
                    }
                }

                break;
            case 2://rectangle
                System.out.println("\nYou have selected: RECTANGLE\n");

                System.out.print("Enter width: ");

                double rWidth = u.nextDouble();

                if (rWidth < 1) {
                    System.out.print("\nERROR: Not a valid entry. ");
                    System.out.print("Enter only values higher than 0\n");
                } else {
                    System.out.print("Enter length: ");

                    double rLength = u.nextDouble();

                    if (rLength < 1) {
                        System.out.print("\nERROR: Not a valid entry. ");
                        System.out.print("Enter only values higher than 0\n");
                    } else {
                        /*only will do calculation with positive values*/

                        double rArea = rLength * rWidth;
                        double rPerim = 2 * (rLength + rWidth);

                        System.out.print("\nThe area of this rectangle is: "
                                + rArea + "\n");
                        System.out.print("The perimeter of this rectangle is: "
                                + " " + rPerim + "\n");
                    }
                }
                break;
            case 3: //circle
                System.out.println("\nYou have selected: CIRCLE\n");

                System.out.print("Enter radius: ");

                double cRad = u.nextDouble();

                if (cRad < 1) {
                    System.out.print("\nERROR: Not a valid entry. ");
                    System.out.print("Enter only values higher than 0\n");
                } else {
                    //will only calculate and print output values if positive
                    double cDiam = 2 * cRad;
                    System.out.print("\nThe diameter of this circle is: ");
                    System.out.print(cDiam + "\n");
                }
                break;

            default:
                System.out.print("\nERROR: Not a valid entry! "
                        + "Negative and 0 numbers are not allowed. "
                        + "Number must be 1, 2, or 3  \n");
        }

        System.out.println("\nCreated by: Krista Ryk 991406369");
    }
}
