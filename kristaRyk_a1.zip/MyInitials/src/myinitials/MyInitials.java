/*
Krista Ryk
991406369
Assignment 1
9/16/20
 */

package myinitials; 

public class MyInitials {

 
    public static void main(String[] args) {
        System.out.println("K\tK\t    A\t\tRRRRRRRR");
        System.out.print("K    K\t\t   A A\t\tR\tR\n");
        System.out.print("K K\t\t  A   A\t\tRRRRRRR\n");
        System.out.print("K    K\t\t AAAAAAA\t\tR     R\n");
        System.out.print("K\tK\tA\tA\tR\tR\n");
        System.out.println("\n\tKrista A. Ryk");
    }
}