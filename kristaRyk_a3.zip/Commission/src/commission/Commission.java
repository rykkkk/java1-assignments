/**
 * Krista Ryk
 * 991406369
 * Assignment 3
 * November 2020
 */
package commission;

import java.util.Scanner;

public class Commission {

    public static void main(String[] args) {

        /*INPUT:
        prompts the user for a Salesperson’s
            first name
            last name
            table sales
            desks sales
            chair sales
         */
        String first, last;
        double tables, desks, chairs;
        double tableComm = 0;
        double deskComm = 0;
        double chairComm = 0;
        double totComm, totSales;
        boolean tryAgain = false;
        
        do {
            System.out.print("Hello!\nEnter first and last name of salesperson followed by the enter key: ");
            Scanner input = new Scanner(System.in);
            first = input.next();
            first = first.substring(0, 1).toUpperCase() + first.substring(1);
            last = input.next();
            last = last.substring(0, 1).toUpperCase() + last.substring(1);
            /*I am just formatting the names to capitalize the first letter,
            I hope this is not too much unnecessary code */

            /*------------------------------------------------------*/
            System.out.printf("Welcome to the Salesperson Commission "
                    + "Calculator, %s %s.\t\n", first, last);
            /*now to check for valid input: 
            - people can have numbers in their names bc those are strings 
                - and nowadays, people name their kids with sybols and nums lol
            - the sales however, must be numbers
                - I have allowed decimal type numbers to be accepted */
/*table sales--------------------------------------------*/
            System.out.print("  Enter your total amount of table sales: $");
            Scanner sales = new Scanner(System.in);
            tables = sales.nextDouble();
            while (tables < 0){
                System.out.print("\tInvalid: Enter valid table sales: $");
                tables = sales.nextDouble();
            }//will  loop until valid input is enterred
            //at this point, table sales is a value either $0 or greater
            
            if(tables < 500){
                tableComm = 10;
            }else if (tables < 1000){
                tableComm = 20;
            }else if (tables < 1500){
                //bug trisha $60 figs brand black scrub pants
                tableComm = 30;
            }else {
                tableComm = 40;
            }
/*desk sales--------------------------------------------*/
            System.out.print("   Enter your total amount of desk sales: $");
            desks = sales.nextDouble();
            while (desks < 0) {
                System.out.print("\t Invalid: Enter valid desk sales: $");
                desks = sales.nextDouble();
            }//will loop until valid input is enterred
            
            if(desks < 500){
                deskComm = 20;
            }else if (desks < 1000){
                deskComm = 30;
            }else if (desks < 1500){
                deskComm = 40;
            }else {
                deskComm = 50;
            }
            
/*chair sales--------------------------------------------*/
            System.out.print("  Enter your total amount of chair sales: $");
            chairs = sales.nextDouble();
            while (chairs < 0){
                System.out.print("\tInvalid: Enter valid chair sales: $");
                chairs = sales.nextDouble();
            }
            
            if(chairs < 500){
                chairComm = 30;
            }else if (chairs < 1000){
                chairComm = 40;
            }else if (chairs < 1500){
                chairComm = 50;
            }else{
                chairComm = 60;
            }
            
/*-----------------------------------------------------------*/
//calculation
            
            totSales = tables + desks + chairs;
            totComm = tableComm + deskComm + chairComm;
            
/*-----------------------------------------------------------*/
            //output
            System.out.printf("\n\tSalesperson name: %s %s",first,last);
            System.out.printf("\n\tTable sales: $%.2f, commission = $%.2f.",
                    tables,tableComm);
            System.out.printf("\n\tDesk sales: $%.2f, commission = $%.2f.",
                    desks,deskComm);
            System.out.printf("\n\tChair sales: $%.2f, commission = $%.2f.",
                    chairs,chairComm);
            System.out.printf("\n\tTotal sales = $%.2f, total commission = "
                    + "$%.2f.",totSales,totComm);
/*End of calculation, for first salesperson. will now ask to try again*/

            System.out.print("\n\nWould you like to calculate commission for "
                    + "another sales agent? (y/n): ");
            Scanner ask = new Scanner(System.in);
            String ans = ask.next();
            if (ans.contains("y")){//if user types anything with a 'y'>try again
                tryAgain = true;
            } else {//if user types anything with no 'y' program will end
                tryAgain = false;
            }
        } while (tryAgain == true);
    }

}
